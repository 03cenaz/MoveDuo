//
//  UploadViewController.swift
//  MoveDuo
//
//  Created by Ecenaz Eğri on 15.08.2024.
//

import UIKit
import FirebaseFirestore
import FirebaseStorage

class UploadViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var activityPicker: UIPickerView!
    @IBOutlet weak var timeToPicker: UIDatePicker!
    @IBOutlet weak var timeFromPicker: UIDatePicker!
    @IBOutlet weak var daysTable: UITableView!
    @IBOutlet weak var validDate: UIDatePicker!
    
    let activities = ["Swing", "Tennis", "Salsa", "Vals", "Tango"]
    let days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        activityPicker.delegate = self
        activityPicker.dataSource = self
        
        daysTable.delegate = self
        daysTable.dataSource = self
        
    }
    
    
    
    // MARK: - UIPickerViewDataSource
        
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return activities.count
    }
    
    // MARK: - UIPickerViewDelegate

    
    // This method allows you to customize the font of the picker view rows
      func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
          let title = activities[row]
          let font = UIFont.systemFont(ofSize: 15)
          let attributes = [NSAttributedString.Key.font: font]
          return NSAttributedString(string: title, attributes: attributes)
      }
    
    
    
    
    // Row - numberOfRowsInSection
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return days.count
    }
    
    // Cell - cellForRowAt
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = String(days[indexPath.row])
        return cell
    }
    
    // didSelectRowAt, when row is selected do this
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let day = days[indexPath.row]
    }
    
    
    
    
    @IBAction func uploadBtnAction(_ sender: Any) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let validDate = dateFormatter.string(from: validDate.date)
    
        let timeFormatter = DateFormatter()
        timeFormatter.timeZone = .current  // Yerel zaman dilimini kullan
        timeFormatter.dateFormat = "HH:mm"
        let timeTo = timeFormatter.string(from: timeToPicker.date)
        let timeFrom = timeFormatter.string(from: timeFromPicker.date)
        
        let selectedRow = activityPicker.selectedRow(inComponent: 0)
        let selectedActivity = activities[selectedRow]
        
        var selectedDays: [String] = []
        if let selectedIndexPaths = daysTable.indexPathsForSelectedRows {
            selectedDays = selectedIndexPaths.map { days[$0.row] }
                }
        
        print("Selected activity: \(selectedActivity) on \(selectedDays) from \(timeFrom) to \(timeTo). valid until \(validDate)")
        
        
        let firestoreDatabase = Firestore.firestore()
        let firestorePost: [String: Any] = [
            "activity": selectedActivity,
            "days": selectedDays,
            "timeFrom": timeFrom,
            "timeTo": timeTo,
            "validDate": validDate,
          //  "email": Auth.auth().currentUser?.email ?? "",
            "date": FieldValue.serverTimestamp()
        ]

        let storage = Storage.storage()
        let storageReference = storage.reference()
        let mediaFolder = storageReference.child("activities")

        // Create a unique identifier for the document
        let uuid = UUID().uuidString
        let documentReference = firestoreDatabase.collection("Post").document(uuid)
        
        documentReference.setData(firestorePost) { error in
            if let error = error {
                Helper.errorMessage(title: "Error", message: "Failed to save activity: \(error.localizedDescription)", vc: self)
            } else {
                // Optionally, you can upload additional files related to the activity if needed
                print("Activity saved successfully.")
                
                self.tabBarController?.selectedIndex = 0 // go to 0. tabBar (Feed)
            }
        }
    
    
        
        
        
        
    }
}
