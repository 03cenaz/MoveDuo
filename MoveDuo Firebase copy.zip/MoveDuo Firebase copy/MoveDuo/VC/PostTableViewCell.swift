//
//  PostTableViewCell.swift
//  MoveDuo
//
//  Created by Ecenaz Eğri on 15.08.2024.
//

import UIKit

class PostTableViewCell: UITableViewCell {

    @IBOutlet weak var profileView: UIImageView!
    @IBOutlet weak var activityLbl: UILabel!
    
    @IBOutlet weak var monLbl: UILabel!
    @IBOutlet weak var tueLbl: UILabel!
    @IBOutlet weak var wedLbl: UILabel!
    @IBOutlet weak var thuLbl: UILabel!
    @IBOutlet weak var friLbl: UILabel!
    @IBOutlet weak var satLbl: UILabel!
    @IBOutlet weak var sunLbl: UILabel!
    
    @IBOutlet weak var timeSlotLbl: UILabel!
    @IBOutlet weak var userInfoLbl: UILabel!
    @IBOutlet weak var validUntilLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func addBtn(_ sender: Any) {
    }
}
