//
//  LogInViewController.swift
//  MoveDuo
//
//  Created by Ecenaz Eğri on 15.08.2024.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore


class LogInViewController: UIViewController,  UIPickerViewDelegate, UIPickerViewDataSource {

    
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var genderLbl: UILabel!
    @IBOutlet weak var birthdayLbl: UILabel!
    
    @IBOutlet weak var usernameTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var genderPicker: UIPickerView!
    @IBOutlet weak var birthdayPicker: UIDatePicker!
    
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var logInBtn: UIButton!
    
    let gender = ["Female", "Male"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        genderPicker.delegate = self
        genderPicker.dataSource = self
    }
    
    // MARK: - UIPickerViewDataSource
        
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return gender.count
    }
    
    // MARK: - UIPickerViewDelegate

    
    // This method allows you to customize the font of the picker view rows
      func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
          let title = gender[row]
          let font = UIFont.systemFont(ofSize: 15)
          let attributes = [NSAttributedString.Key.font: font]
          return NSAttributedString(string: title, attributes: attributes)
      }
    
    
    
    @IBAction func backBtnAction(_ sender: Any) {
        performSegue(withIdentifier: "toBeginningVC", sender: nil)
    }
    
    
    @IBAction func signUpBtnAction(_ sender: Any) {
        
        if emailTxt.text != "" && passwordTxt.text != "" && usernameTxt.text != "" {
            // sign up
            Auth.auth().createUser(withEmail: emailTxt.text!, password: passwordTxt.text!){
                (authDataResult, error) in
                if error != nil {
                    Helper.errorMessage(title: "Error", message: error?.localizedDescription ?? "Error in sign up", vc: self)
                } else if let user = authDataResult?.user {
                    // Save additional user information in Firestore
                    let db = Firestore.firestore()
                    let firestorePost = [
                        "username": self.usernameTxt.text!,
                        "email": self.emailTxt.text!,
                        "gender": self.gender[self.genderPicker.selectedRow(inComponent: 0)],
                        "birthday": self.birthdayPicker.date,
                        "uid": user.uid
                    ]
                    print("Preparing to save user data to Firestore...")
                    db.collection("Users").addDocument(data: firestorePost) { error in
                        if let error = error {
                            print("Error saving user data: \(error.localizedDescription)")
                                                   
                            Helper.errorMessage(title: "Error", message: "Error saving user data: \(error.localizedDescription)", vc: self)
                        } else {
                            print("User data saved successfully!")
                            self.performSegue(withIdentifier: "toMainVC", sender: nil)
                        }
                    }
                }
            }
        } else {
            Helper.errorMessage(title: "Error", message: "Please enter email and password sign up", vc : self)
        }
        
    }
    
    
    @IBAction func logInBtnAction(_ sender: Any) {
        
        if emailTxt.text != "" && passwordTxt.text != "" {
            Auth.auth().signIn(withEmail: emailTxt.text!, password: passwordTxt.text!){
                (authDataResult, error) in
                if error != nil {
                    Helper.errorMessage(title: "Error", message: error?.localizedDescription ?? "Error in log in", vc: self)
                } else {
                    self.performSegue(withIdentifier: "toMainVC", sender: nil)
                }
            }
        } else {
            Helper.errorMessage(title: "Error", message: "Please enter email and password for log in", vc: self)
        }
        
     //   performSegue(withIdentifier: "toMainVC", sender: nil)
    }
    

}

class Helper {
    static func errorMessage(title: String, message: String, vc: UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okBtn = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okBtn)
        vc.present(alert, animated: true)
    }
}
