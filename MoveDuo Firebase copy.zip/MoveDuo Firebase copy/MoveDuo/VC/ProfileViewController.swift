//
//  ProfileViewController.swift
//  MoveDuo
//
//  Created by Ecenaz Eğri on 15.08.2024.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var profileView: UIImageView!
    @IBOutlet weak var usernameTxt: UITextField!
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var genderPicker: UIPickerView!
    @IBOutlet weak var birthdayPicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func saveBtnAction(_ sender: Any) {
    }
    
    @IBAction func logOutBtnAction(_ sender: Any) {
    }
    
}
