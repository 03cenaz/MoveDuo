//
//  BeginningViewController.swift
//  MoveDuo
//
//  Created by Ecenaz Eğri on 15.08.2024.
//

import UIKit

class BeginningViewController: UIViewController {

    var btnType = "btn"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

     
    
    @IBAction func signUpBtnAction(_ sender: Any) {
        btnType = "signUp"
        performSegue(withIdentifier: "toLogInVC", sender: self)
        
    }

    @IBAction func logInBtnAction(_ sender: Any) {
        btnType = "logIn"
        performSegue(withIdentifier: "toLogInVC", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        print(btnType)
        if let logInVC = segue.destination as? LogInViewController {
            
            logInVC.loadViewIfNeeded() // Bu çağrı view'ı yükler
            
            // new user
            if btnType == "signUp" {
                

                logInVC.birthdayLbl.isHidden = false
                logInVC.birthdayPicker.isHidden = false
                logInVC.usernameLbl.isHidden = false
                logInVC.usernameTxt.isHidden = false
                logInVC.genderLbl.isHidden = false
                logInVC.genderPicker.isHidden = false
                
                logInVC.logInBtn.isHidden = true
                logInVC.signUpBtn.isHidden = false

                
            } else if  btnType == "logIn" { // old user

                logInVC.birthdayLbl.isHidden = true
                logInVC.birthdayPicker.isHidden = true
                logInVC.usernameLbl.isHidden = true
                logInVC.usernameTxt.isHidden = true
                logInVC.genderLbl.isHidden = true
                logInVC.genderPicker.isHidden = true
                
                logInVC.logInBtn.isHidden = false
                logInVC.signUpBtn.isHidden = true

            }
        }
        
    }
    
}
